public class Rock : Hazard { }
